PWA Mappa Anni di Piombo - con dataset esterno (events.json)

1. Carica tutti i file in un nuovo repository GitHub (es. anni-di-piombo-mappa).
2. In GitHub: Settings -> Pages -> imposta Branch = main, cartella = root.
3. Apri l'URL fornito da GitHub Pages sul tuo iPhone.
4. Tocca Condividi -> Aggiungi alla schermata Home per installarla come PWA.
